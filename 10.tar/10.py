import binascii
import hashlib

seed = {}
with open('seed.out', 'r') as fp:
    for line in fp:
        s = line[:-1].split(' ')
        seed[s[0]] = (int(s[1]), int(s[2]))

def script(secret1, secret2, user_id, old_hash = None):
    if old_hash is None:
        secret3 = binascii.crc32(user_id)
    else:
        secret3 = binascii.crc32(old_hash)
    if secret3 < 0:
        secret3 += 2 ** 32

    counter = secret3
    counter *= pow(secret1, 10000000, secret2)
    counter %= secret2

    password = ''
    for i in xrange(10):
        counter = counter * secret1 % secret2;
        password += chr(counter % 94 + 33)
    return password, hashlib.md5(password).hexdigest()

for cas in xrange(int(raw_input())):
    print 'Case #%d:' % (cas + 1),
    user_id, count = raw_input().split(' ')
    old_hash = None
    password = None
    for i in xrange(int(count)):
        date, times = raw_input().split(' ')
        secret1, secret2 = seed[date]
        for j in xrange(int(times)):
            password, old_hash = script(secret1, secret2, user_id, old_hash)
    print password
