#include <cstdio>
#include <opencv/cvaux.h>
#include <opencv/cv.h>
#include <opencv/cxcore.h>
#include <opencv/highgui.h>

//  1: 54 x 54
//  2: 64 x 64
//  5: 70 x 70
// 10: 64 x 64
// 20: 72 x 72
// 50: 80 x 80
//100: 76 x 76
//200: 84 x 84

const int N = 1000 + 10;

int S[N][N], cnt[N][N];

int main(int argc, char **argv) {
  cv::Mat img = cv::imread(argv[1]);
  int h = img.rows, w = img.cols;
  //  printf("%d %d\n", h, w);
  const int n = 64;
  const double eo = 0.8, ei = 0.15;
  std::vector<std::pair<int, int>> candidate;
  for (int y = 0; y < h; ++y) {
    for (int x = 0; x < w; ++x) {
      auto v = img.at<cv::Vec3b>(y, x);
      int b = v[0];
      int g = v[1];
      int r = v[2];
      if (b >= 230 && g >= 230 && r >= 230) {
        S[y][x] = 0;
      } else {
        S[y][x] = 1;
        if (x >= n / 2 && y >= n / 2) {
          candidate.emplace_back(y - n / 2, x - n / 2);
        }
      }
    }
  }
  for (int i = h - 1; i >= 0; --i) {
    for (int j = w - 1; j >= 0; --j) {
      cnt[i][j] = !S[i][j] - cnt[i + 1][j] - cnt[i][j + 1] + cnt[i + 1][j + 1];
    }
  }
  std::vector<std::pair<int, int>> all;
  int ret = 0;
  for (auto &&vv: candidate) {
    int i = vv.first;
    int j = vv.second;
    if (i + n > h || j + n > w) continue;
    int inside = 0, outside = 0;
    int sin = 0, sout = 0;
    int cx = n / 2, cy = n / 2;
    int sg = 0, sr = 0, sb = 0;
    int total = cnt[i][j] - cnt[i + n][j] - cnt[i][j + n] + cnt[i + n][j + n];
    if (total * 2 >= n * n) continue;
    for (int x = 0; x < n; ++x) {
      for (int y = 0; y < n; ++y) {
        if ((x - cx) * (x - cx) + (y - cy) * (y - cy) <= n * n / 4) {
          auto v = img.at<cv::Vec3b>(i + x, j + y);
          sb += v[0], sg += v[1], sr += v[2];
          if (!S[i + x][j + y]) ++inside; 
          ++sin;
        } else {
          if (!S[i + x][j + y]) ++outside;
          ++sout;
        }
      }
    }
    //printf("%d %d %.10f %.10f\n", i, j, 1.0 * outside / sout, 1.0 * inside / sin);
    bool valid = 1.0 * outside / sout >= eo && 1.0 * inside / sin <= ei;
    if (valid) {
      bool flag = true;
      for (auto &&e: all) {
        if (abs(e.first - i) + abs(e.second - j) <= 20) flag = false;
      }
      if (flag) {
        if (sb >= 560000) ret += 1;
        else ret += 5;
        all.emplace_back(i, j);
        //printf("%d %d (%d %d %d)\n", i, j, sb, sg, sr);
      }
    }
  }
  return ret;
  printf("==%d %d\n", n, (int)all.size());
  return 0;
}
