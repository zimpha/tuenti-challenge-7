import socket
from socket import errno
import subprocess
import md5
import cv2
import numpy as np

def flip(img, cnt):
    with open('tmp.jpg', 'wb') as fp:
        fp.write(img)
    img = cv2.imread('tmp.jpg')
    h, w, c = img.shape
    t = w / 40
    if w % 40:
        t += 1
    for i in xrange(t):
        if i % 2 == 1:
            l = i * 40
            r = min(l + 40, w)
            data = img[:,l:r,:]
            img[:, l:r, :] = data[:,::-1,:]
    cv2.imwrite('out.jpg', img)

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('52.49.91.111', 3456))

data = []
cnt = 0
len = 0
while True:
    try:
        d = s.recv(1)
        if cnt == 8:
            if len <= 200:
                print d,
            else:
                break
            len += 1
        data.append(d)
        if data[-3:] == ['\xff', '\xd9', '\x0a']:
            jpg = ''.join(data)
            data = []
            len = 0
            key = md5.new(jpg).hexdigest()
            flip(jpg, cnt)
            ss = []
            while True:
                d = s.recv(1)
                ss.append(d)
                if d == '\n':
                    print ''.join(ss)
                    break
            cnt += 1
            if cnt == 1:
                s.send('1\n')
            else:
                s.send(str(subprocess.call(['./one', 'out.jpg']) + subprocess.call(['./two', 'out.jpg']) * 2 + subprocess.call(['./fiv', 'out.jpg']) * 5 + subprocess.call(['./200', 'out.jpg']) * 50 + eval(raw_input())) + '\n')
            ss = []
            while True:
                d = s.recv(1)
                ss.append(d)
                if d == '\n':
                    print ''.join(ss)
                    break
            print 'pass %d\n' % cnt
    except socket.error, e:
        if e.errno != errno.EWOULDBLOCK:
            print '!Error: %r' % e
